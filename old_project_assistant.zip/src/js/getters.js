function getLastRecording() {
    $jsapi.context.checkInterrupted();
    return $jsapi.context.storage.get('lastRecording') || null;
}

function getAllRecordings() {
    $jsapi.context.checkInterrupted();
    return $jsapi.context.storage.get('recordings') || [];
}

function getRecordingByName(name) {
    $jsapi.context.checkInterrupted();
    const recordings = getAllRecordings();
    return recordings.find(recording => recording.name === name) || null;
}

function getRecordingCount() {
    $jsapi.context.checkInterrupted();
    const recordings = getAllRecordings();
    return recordings.length;
}

module.exports = {
    getLastRecording,
    getAllRecordings,
    getRecordingByName,
    getRecordingCount
};
