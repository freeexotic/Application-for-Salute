/**
 * Генерирует ответ на основе намерения пользователя и дополнительных параметров
 * @param {string} intent - Намерение пользователя
 * @param {Object} params - Дополнительные параметры для формирования ответа
 * @returns {string} - Сформированный ответ
 */
function generateReply(intent, params = {}) {
    switch (intent) {
        case "StartRecording":
            return params.isAlreadyRecording 
                ? "Запись уже идет. Скажите 'стоп', чтобы остановить текущую запись."
                : "Начинаю запись. Скажите 'стоп', когда захотите остановить.";
                
        case "StopRecording":
            if (!params.wasRecording) {
                return "Нет активной записи для остановки.";
            }
            const duration = params.duration ? ` Продолжительность: ${params.duration} секунд.` : "";
            return `Запись остановлена и сохранена.${duration}`;
            
        case "PlayRecording":
            if (!params.recordingExists) {
                return "У вас нет сохраненных записей для воспроизведения.";
            }
            const recordingName = params.recordingName ? ` "${params.recordingName}"` : "";
            return `Проигрываю запись${recordingName}.`;
            
        case "DeleteRecording":
            if (!params.recordingExists) {
                return "У вас нет записей для удаления.";
            }
            const deletedName = params.recordingName ? ` "${params.recordingName}"` : "";
            return `Запись${deletedName} удалена.`;
            
        case "ChangeActivationWord":
            const newWord = params.newWord ? ` на "${params.newWord}"` : "";
            return `Кодовое слово изменено${newWord}.`;
            
        case "ListRecordings":
            if (!params.recordingsCount || params.recordingsCount === 0) {
                return "У вас пока нет сохраненных записей.";
            } else if (params.recordingsCount === 1) {
                return "У вас есть 1 запись. Хотите её прослушать?";
            } else {
                return `У вас есть ${params.recordingsCount} записей. Какую хотите прослушать?`;
            }
            
        case "PausePlayback":
            return "Воспроизведение приостановлено. Скажите 'продолжить', чтобы возобновить.";
            
        case "ResumePlayback":
            return "Воспроизведение продолжено.";
            
        case "GetActivationWord":
            const currentWord = params.currentWord || "не установлено";
            return `Ваше текущее кодовое слово: "${currentWord}".`;
            
        case "Help":
            return "Я могу записывать аудио, воспроизводить и управлять вашими записями. " +
                   "Скажите 'начать запись', 'стоп', 'воспроизвести', 'список записей' или 'удалить запись'.";
                   
        default:
            return "Извините, я не понял ваш запрос. Скажите 'помощь', чтобы узнать, что я умею.";
    }
}

module.exports = {
    generateReply
};

