/**
 * Временное хранилище записей (в будущем заменить на постоянное хранилище через API)
 * @type {Object}
 */
var storage = {};

/**
 * Сохраняет запись для указанной сессии
 * @param {string} sessionId - Идентификатор сессии пользователя
 * @param {Object} data - Данные записи
 * @param {string} [name] - Название записи (опционально)
 * @returns {Object} - Сохраненная запись
 */
function saveRecording(sessionId, data, name) {
    if (!storage[sessionId]) {
        storage[sessionId] = [];
    }
    
    const recording = {
        id: generateId(),
        name: name || `Запись ${storage[sessionId].length + 1}`,
        data: data,
        timestamp: Date.now(),
        duration: data.duration || 0
    };
    
    storage[sessionId].push(recording);
    
    // Сохраняем последнюю запись отдельно для быстрого доступа
    storage[`${sessionId}_last`] = recording;
    
    return recording;
}

/**
 * Получает все записи для указанной сессии
 * @param {string} sessionId - Идентификатор сессии пользователя
 * @returns {Array} - Массив записей
 */
function getRecordings(sessionId) {
    return storage[sessionId] || [];
}

/**
 * Получает последнюю запись для указанной сессии
 * @param {string} sessionId - Идентификатор сессии пользователя
 * @returns {Object|null} - Последняя запись или null
 */
function getLastRecording(sessionId) {
    return storage[`${sessionId}_last`] || null;
}

/**
 * Получает запись по ID для указанной сессии
 * @param {string} sessionId - Идентификатор сессии пользователя
 * @param {string} recordingId - Идентификатор записи
 * @returns {Object|null} - Найденная запись или null
 */
function getRecordingById(sessionId, recordingId) {
    const recordings = getRecordings(sessionId);
    return recordings.find(rec => rec.id === recordingId) || null;
}

/**
 * Получает запись по имени для указанной сессии
 * @param {string} sessionId - Идентификатор сессии пользователя
 * @param {string} name - Название записи
 * @returns {Object|null} - Найденная запись или null
 */
function getRecordingByName(sessionId, name) {
    const recordings = getRecordings(sessionId);
    return recordings.find(rec => rec.name === name) || null;
}

/**
 * Удаляет все записи для указанной сессии
 * @param {string} sessionId - Идентификатор сессии пользователя
 */
function deleteAllRecordings(sessionId) {
    if (storage[sessionId]) {
        delete storage[sessionId];
    }
    if (storage[`${sessionId}_last`]) {
        delete storage[`${sessionId}_last`];
    }
}

/**
 * Удаляет запись по ID для указанной сессии
 * @param {string} sessionId - Идентификатор сессии пользователя
 * @param {string} recordingId - Идентификатор записи
 * @returns {boolean} - Успешность удаления
 */
function deleteRecordingById(sessionId, recordingId) {
    if (!storage[sessionId]) {
        return false;
    }
    
    const initialLength = storage[sessionId].length;
    storage[sessionId] = storage[sessionId].filter(rec => rec.id !== recordingId);
    
    // Если была удалена последняя запись, обновляем ссылку
    if (storage[`${sessionId}_last`] && storage[`${sessionId}_last`].id === recordingId) {
        storage[`${sessionId}_last`] = storage[sessionId].length > 0 ? 
            storage[sessionId][storage[sessionId].length - 1] : null;
    }
    
    return storage[sessionId].length < initialLength;
}

/**
 * Генерирует уникальный идентификатор
 * @returns {string} - Уникальный ID
 */
function generateId() {
    return Math.random().toString(36).substring(2, 15) + 
           Math.random().toString(36).substring(2, 15);
}

module.exports = {
    saveRecording,
    getRecordings,
    getLastRecording,
    getRecordingById,
    getRecordingByName,
    deleteAllRecordings,
    deleteRecordingById
};

