// Временное хранилище записей в памяти (заменить на API-хранилище)
var recordings = {};

function startRecording(context) {
    const sessionId = context.sessionId;
    if (recordings[sessionId] && recordings[sessionId].recording) {
        context.sendResponse("Запись уже идет. Скажите 'стоп', чтобы остановить текущую запись.");
    } else {
        context.sendResponse("Запись началась.");
        recordings[sessionId] = { recording: true, data: [], startTime: Date.now() };
    }
}

function stopRecording(context) {
    const sessionId = context.sessionId;
    if (recordings[sessionId] && recordings[sessionId].recording) {
        recordings[sessionId].recording = false;
        recordings[sessionId].endTime = Date.now();
        const duration = (recordings[sessionId].endTime - recordings[sessionId].startTime) / 1000;
        context.sendResponse(`Запись остановлена. Продолжительность: ${duration.toFixed(1)} секунд.`);
    } else {
        context.sendResponse("Нет активной записи.");
    }
}

function playRecording(context) {
    const sessionId = context.sessionId;
    if (recordings[sessionId] && recordings[sessionId].data.length > 0) {
        context.sendResponse("Проигрываю последнюю запись.");
        // Здесь можно добавить вызов API для воспроизведения
        // Например: context.sendAudio(recordings[sessionId].data);
    } else {
        context.sendResponse("Нет записей для воспроизведения.");
    }
}

function deleteRecording(context) {
    const sessionId = context.sessionId;
    if (recordings[sessionId]) {
        delete recordings[sessionId];
        context.sendResponse("Последняя запись удалена.");
    } else {
        context.sendResponse("Нет записей для удаления.");
    }
}

function listRecordings(context) {
    const sessionId = context.sessionId;
    if (recordings[sessionId]) {
        const recordingInfo = recordings[sessionId];
        const duration = recordingInfo.endTime ? 
            ((recordingInfo.endTime - recordingInfo.startTime) / 1000).toFixed(1) : 
            "в процессе";
        context.sendResponse(`У вас есть 1 запись. Продолжительность: ${duration} секунд.`);
    } else {
        context.sendResponse("У вас нет сохраненных записей.");
    }
}

module.exports = { 
    startRecording, 
    stopRecording, 
    playRecording, 
    deleteRecording,
    listRecordings
};
