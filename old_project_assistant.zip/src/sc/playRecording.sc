theme: /
    state: PlayRecording
        q!: * (включи|воспроизведи|проиграй) [эту|текущую|последнюю] запись *
        q!: * (включи|воспроизведи|проиграй) запись [под названием|с именем] * {$RecordingName=$nonEmptyGarbage} *
        
        script:
            log('playRecording: Запрос на воспроизведение записи');
            
            if ($RecordingName) {
                $session.selectedRecording = $RecordingName;
            } else if (!$session.selectedRecording) {
                $temp.lastRecording = $jsapi.storage.getLastRecording($jsapi.context.sessionId);
                if ($temp.lastRecording) {
                    $session.selectedRecording = $temp.lastRecording.name;
                }
            }
            
            if ($session.selectedRecording) {
                log('playRecording: Попытка воспроизведения записи ' + $session.selectedRecording);
                $temp.playResult = $actions.playRecording($session.selectedRecording);
                
                if ($temp.playResult.success) {
                    $reactions.answer("Воспроизвожу запись \"" + $session.selectedRecording + "\".");
                    go!: /PlaybackControls
                } else {
                    $reactions.answer("Извините, не удалось воспроизвести запись \"" + $session.selectedRecording + "\". " + $temp.playResult.error);
                }
            } else {
                $reactions.answer("У вас нет сохраненных записей для воспроизведения. Хотите начать новую запись?");
                go!: /StartNewRecording
            }

    state: PlaybackControls
        q: * (пауза|останови|прекрати|стоп) *
        script:
            log('playRecording: Запрос на паузу воспроизведения');
            $temp.pauseResult = $actions.pausePlayback();
            if ($temp.pauseResult.success) {
                $reactions.answer("Воспроизведение приостановлено. Скажите \"продолжить\", чтобы возобновить.");
            } else {
                $reactions.answer("Извините, не удалось приостановить воспроизведение. " + $temp.pauseResult.error);
            }
        go!: /

        q: * (продолжи|возобнови|дальше) *
        script:
            log('playRecording: Запрос на возобновление воспроизведения');
            $temp.resumeResult = $actions.resumePlayback();
            if ($temp.resumeResult.success) {
                $reactions.answer("Воспроизведение продолжено.");
            } else {
                $reactions.answer("Извините, не удалось возобновить воспроизведение. " + $temp.resumeResult.error);
            }
        go!: /

        q: * (повтори|заново|сначала) *
        script:
            log('playRecording: Запрос на повторное воспроизведение');
            if ($session.selectedRecording) {
                $temp.playResult = $actions.playRecording($session.selectedRecording);
                if ($temp.playResult.success) {
                    $reactions.answer("Воспроизвожу запись \"" + $session.selectedRecording + "\" заново.");
                } else {
                    $reactions.answer("Извините, не удалось повторно воспроизвести запись. " + $temp.playResult.error);
                }
            } else {
                $reactions.answer("Извините, не удалось определить, какую запись повторить.");
            }
        go!: /

        q: * (следующая|следующую) [запись] *
        script:
            log('playRecording: Запрос на воспроизведение следующей записи');
            $temp.nextRecording = $actions.getNextRecording($session.selectedRecording);
            if ($temp.nextRecording) {
                $session.selectedRecording = $temp.nextRecording.name;
                $temp.playResult = $actions.playRecording($session.selectedRecording);
                if ($temp.playResult.success) {
                    $reactions.answer("Воспроизвожу следующую запись \"" + $session.selectedRecording + "\".");
                } else {
                    $reactions.answer("Извините, не удалось воспроизвести следующую запись. " + $temp.playResult.error);
                }
            } else {
                $reactions.answer("Это была последняя запись в списке.");
            }
        go!: /

        q: * (предыдущая|предыдущую) [запись] *
        script:
            log('playRecording: Запрос на воспроизведение предыдущей записи');
            $temp.prevRecording = $actions.getPreviousRecording($session.selectedRecording);
            if ($temp.prevRecording) {
                $session.selectedRecording = $temp.prevRecording.name;
                $temp.playResult = $actions.playRecording($session.selectedRecording);
                if ($temp.playResult.success) {
                    $reactions.answer("Воспроизвожу предыдущую запись \"" + $session.selectedRecording + "\".");
                } else {
                    $reactions.answer("Извините, не удалось воспроизвести предыдущую запись. " + $temp.playResult.error);
                }
            } else {
                $reactions.answer("Это была первая запись в списке.");
            }
        go!: /

        event: noMatch
        a: Извините, я не понял вашу команду. Вы можете сказать "пауза", "продолжить", "повторить", "следующая" или "предыдущая".
        go!: .

    state: StartNewRecording
        q: * (да|хочу|начать|давай) *
        a: Отлично! Давайте начнем новую запись. Скажите "Начать запись", когда будете готовы.
        go!: /StartRecording

        q: * (нет|не хочу|не надо) *
        a: Хорошо. Если захотите начать запись позже, просто скажите "Начать запись".
        go!: /


