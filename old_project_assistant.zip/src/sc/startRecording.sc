theme: /
    state: StartRecording
        q!: * (начать|начни|старт|стартуй|запусти) [новую] запись *
        q!: * (записывай|запиши|включи) [пожалуйста] [диктофон|запись] *
        
        script:
            log('startRecording: Запрос на начало записи');
            
            // Проверяем, не идет ли уже запись
            if ($session.isRecording) {
                $reactions.answer("Запись уже идет. Скажите 'стоп' или 'остановить запись', когда закончите.");
                go!: /Listening
            }
            
            // Начинаем новую запись
            try {
                $temp.recordingResult = $actions.startRecording($jsapi.context.sessionId);
                
                if ($temp.recordingResult.success) {
                    $session.isRecording = true;
                    $session.recordingStartTime = Date.now();
                    $session.recordingName = $temp.recordingResult.name || "Запись " + new Date().toLocaleString('ru');
                    
                    $reactions.answer("Запись началась. Говорите, я вас слушаю. Скажите 'стоп', когда закончите.");
                    go!: /Listening
                } else {
                    $reactions.answer("Извините, не удалось начать запись: " + $temp.recordingResult.error);
                }
            } catch (e) {
                log('startRecording: Ошибка при начале записи: ' + e.message);
                $reactions.answer("Произошла ошибка при начале записи. Пожалуйста, попробуйте позже.");
            }

    state: Listening
        q: * (остановить|останови|закончить|заверши|стоп) [эту] запись *
        script:
            log('startRecording: Запрос на остановку записи');
            
            if (!$session.isRecording) {
                $reactions.answer("В данный момент нет активной записи.");
                go!: /
            }
            
            try {
                $temp.recordingDuration = Math.round((Date.now() - $session.recordingStartTime) / 1000);
                $temp.stopResult = $actions.stopRecording($jsapi.context.sessionId, $session.recordingName);
                
                if ($temp.stopResult.success) {
                    $session.isRecording = false;
                    $reactions.answer("Запись \"" + $session.recordingName + "\" остановлена и сохранена. Продолжительность: " + $temp.recordingDuration + " секунд. Хотите прослушать?");
                    go!: /AskToPlay
                } else {
                    $reactions.answer("Извините, возникла проблема при остановке записи: " + $temp.stopResult.error);
                }
            } catch (e) {
                log('startRecording: Ошибка при остановке записи: ' + e.message);
                $reactions.answer("Произошла ошибка при остановке записи. Пожалуйста, попробуйте еще раз.");
            }

        q: * (пауза|приостановить) [запись] *
        script:
            log('startRecording: Запрос на паузу записи');
            
            if (!$session.isRecording) {
                $reactions.answer("В данный момент нет активной записи.");
                return;
            }
            
            try {
                $temp.pauseResult = $actions.pauseRecording($jsapi.context.sessionId);
                
                if ($temp.pauseResult.success) {
                    $session.isRecordingPaused = true;
                    $reactions.answer("Запись приостановлена. Скажите 'продолжить', чтобы возобновить, или 'стоп', чтобы завершить.");
                } else {
                    $reactions.answer("Извините, не удалось приостановить запись: " + $temp.pauseResult.error);
                }
            } catch (e) {
                log('startRecording: Ошибка при паузе записи: ' + e.message);
                $reactions.answer("Произошла ошибка при приостановке записи.");
            }
        go!: .

        q: * (продолжить|возобновить|дальше) [запись] *
        script:
            log('startRecording: Запрос на возобновление записи');
            
            if (!$session.isRecording || !$session.isRecordingPaused) {
                $reactions.answer("Нет приостановленной записи для возобновления.");
                return;
            }
            
            try {
                $temp.resumeResult = $actions.resumeRecording($jsapi.context.sessionId);
                
                if ($temp.resumeResult.success) {
                    $session.isRecordingPaused = false;
                    $reactions.answer("Запись возобновлена. Продолжайте говорить.");
                } else {
                    $reactions.answer("Извините, не удалось возобновить запись: " + $temp.resumeResult.error);
                }
            } catch (e) {
                log('startRecording: Ошибка при возобновлении записи: ' + e.message);
                $reactions.answer("Произошла ошибка при возобновлении записи.");
            }
        go!: .

        q: * (назвать|назови|имя|название) [эту] запись * {$RecordingName=$nonEmptyGarbage} *
        script:
            log('startRecording: Запрос на переименование текущей записи на: ' + $RecordingName);
            
            if (!$session.isRecording) {
                $reactions.answer("В данный момент нет активной записи для переименования.");
                return;
            }
            
            $session.recordingName = $RecordingName;
            $reactions.answer("Хорошо, текущая запись будет сохранена с названием \"" + $session.recordingName + "\".");
        go!: .

        q: * (выход|выйти|закрыть|завершить) [приложение|программу] *
        script:
            log('startRecording: Запрос на выход из приложения');
            
            if ($session.isRecording) {
                $reactions.answer("У вас есть активная запись. Хотите сохранить её перед выходом?");
                go!: /AskToSaveBeforeExit
            } else {
                $reactions.answer("Закрываю приложение. До свидания!");
                go!: /
            }

        event: noMatch
        script:
            // Продолжаем запись при любых других фразах
            log('startRecording: Запись продолжается, получен текст: ' + $request.query);
            
            // Здесь можно добавить логику для сохранения текста в запись
            if ($session.isRecording && !$session.isRecordingPaused) {
                // Например: $actions.addTextToRecording($jsapi.context.sessionId, $request.query);
            }
        go!: .

    state: AskToPlay
        q: * (да|хочу|давай|включи|воспроизведи) *
        script:
            log('startRecording: Запрос на воспроизведение только что записанной записи');
            $temp.playResult = $actions.playRecording($session.recordingName);
            
            if ($temp.playResult.success) {
                $reactions.answer("Воспроизвожу запись \"" + $session.recordingName + "\".");
            } else {
                $reactions.answer("Извините, не удалось воспроизвести запись: " + $temp.playResult.error);
            }
        go!: /

        q: * (нет|не надо|не хочу|потом) *
        a: Хорошо. Запись сохранена и доступна в списке записей.
        go!: /

    state: AskToSaveBeforeExit
        q: * (да|сохрани|сохранить) *
        script:
            log('startRecording: Сохранение записи перед выходом');
            $temp.stopResult = $actions.stopRecording($jsapi.context.sessionId, $session.recordingName);
            
            if ($temp.stopResult.success) {
                $session.isRecording = false;
                $reactions.answer("Запись \"" + $session.recordingName + "\" сохранена. Закрываю приложение. До свидания!");
            } else {
                $reactions.answer("Извините, возникла проблема при сохранении записи: " + $temp.stopResult.error + " Закрываю приложение.");
            }
        go!: /

        q: * (нет|не надо|не сохраняй) *
        script:
            log('startRecording: Отмена записи перед выходом');
            $temp.cancelResult = $actions.cancelRecording($jsapi.context.sessionId);
            
            if ($temp.cancelResult.success) {
                $session.isRecording = false;
                $reactions.answer("Запись отменена. Закрываю приложение. До свидания!");
            } else {
                $reactions.answer("Извините, возникла проблема при отмене записи. Закрываю приложение.");
            }
        go!: /
