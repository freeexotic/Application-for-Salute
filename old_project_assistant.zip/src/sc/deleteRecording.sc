theme: /
    state: DeleteRecording
        q!: * (удали|стереть|удалить|убрать) [эту|текущую|последнюю] запись [пожалуйста] *
        q!: * (удали|стереть|удалить|убрать) запись [под названием|с именем] * {$НазваниеЗаписи=$words} *
        
        script:
            // Если указано название записи
            if ($НазваниеЗаписи) {
                $session.recordingToDelete = $НазваниеЗаписи;
                log('deleteRecording: Запрос на удаление записи с названием: ' + $session.recordingToDelete);
            } else {
                // Если название не указано, берем последнюю запись
                $temp.lastRecording = $jsapi.storage.getLastRecording($jsapi.context.sessionId);
                if ($temp.lastRecording) {
                    $session.recordingToDelete = $temp.lastRecording.name;
                    log('deleteRecording: Запрос на удаление последней записи: ' + $session.recordingToDelete);
                } else {
                    log('deleteRecording: Нет записей для удаления');
                    $reactions.answer("У вас нет сохраненных записей для удаления.");
                    return;
                }
            }
            
            // Проверяем существование записи
            $temp.recordingExists = $jsapi.storage.getRecordingByName($jsapi.context.sessionId, $session.recordingToDelete);
            if (!$temp.recordingExists) {
                $reactions.answer("Запись с названием \"{{$session.recordingToDelete}}\" не найдена.");
                return;
            }
            
            $reactions.answer("Вы уверены, что хотите удалить запись \"{{$session.recordingToDelete}}\"?");
        
        go!: /ConfirmDelete

    state: ConfirmDelete
        q: * (да|удали|подтверждаю|верно|точно|конечно) *
        script:
            log('deleteRecording: Подтверждение удаления записи ' + $session.recordingToDelete);
            
            try {
                $temp.result = $jsapi.storage.deleteRecordingByName($jsapi.context.sessionId, $session.recordingToDelete);
                
                if ($temp.result) {
                    $reactions.answer("Запись \"{{$session.recordingToDelete}}\" успешно удалена.");
                } else {
                    $reactions.answer("Не удалось удалить запись \"{{$session.recordingToDelete}}\". Возможно, она уже была удалена.");
                }
                
                // Очищаем данные сессии
                delete $session.recordingToDelete;
            } catch (e) {
                log('deleteRecording: Ошибка при удалении записи: ' + e.message);
                $reactions.answer("Произошла ошибка при удалении записи. Пожалуйста, попробуйте позже.");
            }
        
        go!: /

        q: * (нет|отмена|отменить|не надо|не хочу) *
        script:
            delete $session.recordingToDelete;
        a: Отмена удаления. Запись сохранена.
        go!: /

        event: noMatch
        a: Пожалуйста, ответьте "да" или "нет".
        go: .

