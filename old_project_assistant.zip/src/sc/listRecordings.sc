theme: /
    state: ListRecordings
        q!: * (какие|какой) [у меня] есть записи *
        q!: * (список|перечень) [моих] записей *
        q!: * покажи [мне] [все] [мои] записи *
        
        script:
            log('listRecordings: Запрос списка записей');
            $temp.recordings = $jsapi.storage.getRecordings($jsapi.context.sessionId);
            
            if ($temp.recordings && $temp.recordings.length > 0) {
                $session.recordingsList = $temp.recordings.map(rec => rec.name);
                
                if ($temp.recordings.length === 1) {
                    $reactions.answer("У вас есть одна запись: \"" + $session.recordingsList[0] + "\". Хотите её прослушать?");
                } else {
                    $reactions.answer("Вот список ваших записей:\n" + $session.recordingsList.map((name, index) => (index + 1) + ". " + name).join("\n") + "\n\nКакую запись хотите прослушать?");
                }
            } else {
                $reactions.answer("У вас пока нет сохраненных записей. Хотите начать новую запись?");
                go!: /StartNewRecording
            }
        
        go!: /ChooseRecording

    state: ChooseRecording
        q: * {$number::Number} *
        script:
            if ($session.recordingsList && $number > 0 && $number <= $session.recordingsList.length) {
                $session.selectedRecording = $session.recordingsList[$number - 1];
                log('listRecordings: Выбрана запись по номеру: ' + $session.selectedRecording);
                $reactions.answer("Вы выбрали запись \"" + $session.selectedRecording + "\". Воспроизвожу.");
                go!: /PlayRecording
            } else {
                $reactions.answer("Извините, но записи с таким номером нет. Пожалуйста, выберите номер из списка.");
            }

        q: * (включи|воспроизведи|проиграй) [запись] * {$RecordingName=$nonEmptyGarbage} *
        script:
            $session.selectedRecording = $RecordingName;
            log('listRecordings: Выбрана запись по названию: ' + $session.selectedRecording);
            
            if ($session.recordingsList && $session.recordingsList.includes($session.selectedRecording)) {
                $reactions.answer("Воспроизвожу запись \"" + $session.selectedRecording + "\".");
                go!: /PlayRecording
            } else {
                $reactions.answer("Извините, но записи с названием \"" + $session.selectedRecording + "\" не найдено. Пожалуйста, выберите запись из списка.");
            }

        event: noMatch
        a: Извините, я не понял, какую запись вы хотите прослушать. Пожалуйста, назовите номер или название записи из списка.
        go!: .

    state: StartNewRecording
        q: * (да|хочу|начать|давай) *
        a: Отлично! Давайте начнем новую запись. Скажите "Начать запись", когда будете готовы.
        go!: /StartRecording

        q: * (нет|не хочу|не надо) *
        a: Хорошо. Если захотите начать запись позже, просто скажите "Начать запись".
        go!: /

    state: PlayRecording
        script:
            // Здесь должна быть логика воспроизведения выбранной записи
            log('listRecordings: Воспроизведение записи: ' + $session.selectedRecording);
            // Пример: $actions.playRecording($session.selectedRecording);
        a: Воспроизвожу запись "{{$session.selectedRecording}}".
        go!: /
