theme: /
    state: ChangeKeyword
        q!: * (измени|поменяй|смени|установи) [новое|другое] кодовое слово [на|для] * {$НовоеСлово=$words}
        q!: * (сменить|изменить) [кодовое] (слово|активацию) [на] * {$НовоеСлово=$words}
        script:
            $session.newKeyword = $НовоеСлово;
            log('changeKeyword: Запрос на изменение кодового слова на ' + $session.newKeyword);
        a: Вы уверены, что хотите установить "{{$session.newKeyword}}" как новое кодовое слово?
        go!: /ConfirmKeywordChange

    state: ConfirmKeywordChange
        q: * (да|подтверждаю|установи|верно|правильно|конечно) *
        script:
            log('changeKeyword: Установка нового кодового слова ' + $session.newKeyword);
            try {
                $temp.result = $actions.setActivationWord($session.newKeyword);
                if ($temp.result.success) {
                    $reactions.answer("Кодовое слово успешно изменено на \"{{$session.newKeyword}}\".");
                } else {
                    $reactions.answer("Не удалось изменить кодовое слово: {{$temp.result.error}}");
                }
            } catch (e) {
                log('changeKeyword: Ошибка при установке кодового слова: ' + e.message);
                $reactions.answer("Произошла ошибка при изменении кодового слова. Пожалуйста, попробуйте позже.");
            }
        go!: /

        q: * (нет|отмена|отменить|не надо|не хочу) *
        script:
            delete $session.newKeyword;
        a: Отмена изменения. Кодовое слово осталось прежним.
        go!: /

        event: noMatch
        a: Пожалуйста, ответьте "да" или "нет".
        go: .
