theme: /
    state: StopRecording
        q!: * (остановить|останови|закончить|заверши|стоп) [эту] запись *
        q!: * (сохрани|сохранить) [эту|текущую] запись *
        
        script:
            log('stopRecording: Запрос на остановку записи');
            
            // Проверяем, идет ли запись
            if (!$session.isRecording) {
                $reactions.answer("В данный момент нет активной записи для остановки.");
                go!: /
            }
            
            try {
                // Рассчитываем продолжительность записи
                $temp.recordingDuration = Math.round((Date.now() - $session.recordingStartTime) / 1000);
                
                // Получаем имя записи или используем временное
                $temp.recordingName = $session.recordingName || ("Запись от " + new Date().toLocaleString('ru'));
                
                // Останавливаем запись
                $temp.stopResult = $actions.stopRecording($jsapi.context.sessionId, $temp.recordingName);
                
                if ($temp.stopResult.success) {
                    // Обновляем состояние сессии
                    $session.isRecording = false;
                    $session.lastRecordingName = $temp.recordingName;
                    
                    // Формируем ответ с информацией о записи
                    $reactions.answer("Запись \"" + $temp.recordingName + "\" остановлена и сохранена. " + 
                                     "Продолжительность: " + $temp.recordingDuration + " секунд.");
                    
                    // Предлагаем прослушать запись
                    go!: /PlaybackOptions
                } else {
                    $reactions.answer("Извините, возникла проблема при сохранении записи: " + $temp.stopResult.error);
                }
            } catch (e) {
                log('stopRecording: Ошибка при остановке записи: ' + e.message);
                $reactions.answer("Произошла ошибка при остановке записи. Пожалуйста, попробуйте еще раз.");
            }

    state: PlaybackOptions
        a: Хотите прослушать запись?
        
        q: * (да|хочу|давай|включи|воспроизведи) *
        script:
            log('stopRecording: Запрос на воспроизведение только что сохраненной записи');
            
            if (!$session.lastRecordingName) {
                $reactions.answer("Извините, не удалось найти последнюю запись для воспроизведения.");
                go!: /
            }
            
            try {
                $temp.playResult = $actions.playRecording($session.lastRecordingName);
                
                if ($temp.playResult.success) {
                    $reactions.answer("Воспроизвожу запись \"" + $session.lastRecordingName + "\".");
                    go!: /PlayRecording
                } else {
                    $reactions.answer("Извините, не удалось воспроизвести запись: " + $temp.playResult.error);
                }
            } catch (e) {
                log('stopRecording: Ошибка при воспроизведении записи: ' + e.message);
                $reactions.answer("Произошла ошибка при воспроизведении записи.");
            }
        go!: /

        q: * (нет|не нужно|не хочу|потом) *
        a: Хорошо, запись сохранена. Вы можете найти её в списке записей позже.
        go!: /

        q: * (переименовать|переименуй|изменить название|изменить имя) *
        a: Как вы хотите назвать эту запись?
        go!: /RenameRecording

        event: noMatch
        a: Пожалуйста, ответьте "да", если хотите прослушать запись, или "нет", если хотите продолжить.
        go!: .

    state: RenameRecording
        q: * {$NewName=$nonEmptyGarbage} *
        script:
            log('stopRecording: Запрос на переименование записи на: ' + $NewName);
            
            if (!$session.lastRecordingName) {
                $reactions.answer("Извините, не удалось найти последнюю запись для переименования.");
                go!: /
            }
            
            try {
                $temp.renameResult = $actions.renameRecording($session.lastRecordingName, $NewName);
                
                if ($temp.renameResult.success) {
                    $session.lastRecordingName = $NewName;
                    $reactions.answer("Запись переименована в \"" + $NewName + "\". Хотите прослушать её?");
                    go!: /PlaybackOptions
                } else {
                    $reactions.answer("Извините, не удалось переименовать запись: " + $temp.renameResult.error);
                }
            } catch (e) {
                log('stopRecording: Ошибка при переименовании записи: ' + e.message);
                $reactions.answer("Произошла ошибка при переименовании записи.");
            }
        go!: /

        event: noMatch
        a: Пожалуйста, укажите новое название для записи.
        go!: .

