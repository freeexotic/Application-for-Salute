require: js/getters.js
require: js/reply.js
require: js/actions.js
require: js/storage.js

# Подключение сценарных файлов
require: sc/startRecording.sc
require: sc/stopRecording.sc
require: sc/playRecording.sc
require: sc/changeKeyword.sc
require: sc/listRecordings.sc
require: sc/deleteRecording.sc

patterns:
    $AnyText = $nonEmptyGarbage
    $words = $nonEmptyGarbage
    
    # Паттерны для работы с записями
    $RecordingName = $nonEmptyGarbage
    $НазваниеЗаписи = $nonEmptyGarbage
    $NewName = $nonEmptyGarbage
    
    # Паттерны для работы с кодовыми словами
    $НовоеСлово = $nonEmptyGarbage
    
    # Паттерны для чисел
    $number = $numberRu || $numberEn

theme: /
    state: Start
        # Запуск приложения голосом или кнопкой
        q!: $regex</start>
        q!: (запусти | открой | включи) big ears
        a: Привет! Я ваш голосовой помощник для записей. Скажите "начать запись", "прослушать записи" или "изменить кодовое слово".

    state: Help
        q!: * (помощь|помоги|что ты умеешь|как пользоваться|инструкция|справка) *
        a: Я могу записывать аудио, воспроизводить и управлять вашими записями. Вот что я умею:
           - "Начать запись" - начинаю запись голоса
           - "Стоп" или "Остановить запись" - останавливаю и сохраняю запись
           - "Воспроизвести запись" - проигрываю последнюю запись
           - "Список записей" - показываю все ваши записи
           - "Удалить запись" - удаляю запись
           - "Изменить кодовое слово" - меняю слово активации
           - "Выход" - закрываю приложение

    state: Exit
        q!: * (выход|выйти|закрыть|завершить работу|выключить|до свидания|пока) *
        script:
            if ($session.isRecording) {
                $reactions.answer("У вас есть активная запись. Хотите сохранить её перед выходом?");
                go!: /AskToSaveBeforeExit
            } else {
                $reactions.answer("Закрываю приложение. До свидания!");
            }
        go!: /

    state: AskToSaveBeforeExit
        q: * (да|сохрани|сохранить) *
        script:
            $temp.stopResult = $actions.stopRecording($jsapi.context.sessionId, $session.recordingName);
            if ($temp.stopResult.success) {
                $session.isRecording = false;
                $reactions.answer("Запись сохранена. Закрываю приложение. До свидания!");
            } else {
                $reactions.answer("Не удалось сохранить запись. Закрываю приложение.");
            }
        go!: /

        q: * (нет|не надо|не сохраняй) *
        script:
            $actions.cancelRecording($jsapi.context.sessionId);
            $session.isRecording = false;
            $reactions.answer("Запись отменена. Закрываю приложение. До свидания!");
        go!: /

    state: Fallback
        event!: noMatch
        script:
            log('entryPoint: Fallback: context: ' + JSON.stringify($context))
        a: Извините, я не понимаю. Попробуйте сказать "начать запись", "прослушать записи" или скажите "помощь".


