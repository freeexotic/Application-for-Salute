const button = document.getElementById('recButton'); // Кнопка записи
const audioPlayer = document.getElementById('currentRecord'); // Плеер для записи

let mediaRecorder; //Объект для записи аудио
let audioChunks = []; // Массив для хранения записанных данных
let isRecording = false; // Флаг записи
let stream;

// Обработчик нажатия на кнопку
button.addEventListener("click", async () => {
    // Если запись уже идёт, то останавливаем запись
    if (isRecording) {
        mediaRecorder.stop(); // Останавливаем запись
        button.style.backgroundColor = 'white'; // Меняем стиль кнопки
        isRecording = false; // Сбрасываем флаг
    } else {
        if (!stream) {
            stream = await navigator.mediaDevices.getUserMedia({ audio: true});
        }
        // Проверяем, есть ли доступ к микрофону
        try {
            
            /*
            navigator - глобальный объект, через который можно получить доступ к медиаустройствам
            к. с. await останавливает выполнение скрипта до выполнения функции getUserMedia
            getUserMedia запрашивает доступ к аудиоустройствам
            */
            //присваиваем mediaRecorder объект для записи аудио
            mediaRecorder = new MediaRecorder(stream);
            /*
            когда данные доступны, записываем их в audioChunks
            */
            mediaRecorder.ondataavailable = (event) => {
                audioChunks.push(event.data);
            };
            
            /*
            когда прекращается запись, создаём объект Blob из audioChunks
            и присваиваем его audioPlayer.src
            */
           /*
            mediaRecorder.onstop = () => {
                //чтобы реализовать возможность обмена аудио со страницей archive,
                //потребовалось создать объект reader (я пока не знаю всех его свойств),
                //который читает данные из Blob как URL
                const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
                const reader = new FileReader();
                reader.readAsDataURL(audioBlob);
                reader.onloadend = () => {
                    //результат чтения Blob объектом reader записывается в base64data
                    //если честно, я не знаю, что такое base64data
                    //(не как объект в данном скрипте, а как формат данных в целом)
                    const base64data = reader.result;
                    audioPlayer.src = base64data;
                    audioChunks = [];

                    //здесь алгоритм, сохраняющий запись в localStorage
                    let count = localStorage.getItem('audioCount') || 0;
                    count = parseInt(count, 10);
                    localStorage.setItem('audioCount', count + 1);
                    localStorage.setItem(count, base64data);
                }
            };
            */

            mediaRecorder.onstop = () => {
                const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
                const reader = new FileReader();
                reader.readAsDataURL(audioBlob);
                const now = new Date();
                reader.onloadend = () => {
                    const base64data = reader.result;
                    audioPlayer.src = base64data;
                    audioChunks = [];

                    let count = localStorage.getItem('audioCount') || 0;
                    count = parseInt(count, 10);
                    localStorage.setItem('audioCount', count + 1);
                    localStorage.setItem(count, now);
                    localStorage.setItem(now, base64data);
                }
            }

            mediaRecorder.start(); //запись
            button.style.backgroundColor = 'red'; // меняем стиль кнопки
            isRecording = true; // устанавливаем флаг записи
        } catch (err) {
            console.error("Ошибка доступа к микрофону");
        }
    }
})



//пррррр скибиди доп доп доп ес ес ес ес