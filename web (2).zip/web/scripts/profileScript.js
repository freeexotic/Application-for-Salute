const profileBody = document.getElementById("profileBody");

//АДРЕС СЕРВЕРА СЮДООООО
let serverAddress;

let responseMsg = 'пррррр';

function makeAddress() {
    serverAddress = new URL(document.getElementById("serverAddress").value);
}

const authorizationData = {
    login:'',
    password: '',
    setValues: function (l , p) {
        this.login = l;
        this.password = p;
    },
    checkData: function(serverAddress) {
        fetch (serverAddress, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                login: this.login,
                password: this.password

            })
        })
        .then(response => response.json())
        .then(data => {
            localStorage.setItem('authorized', '1');
            responseMsg = data;
        })
        .then(error => {
            console.error('Ошибка', error);
        });
        return localStorage.getItem('authorized');
    }
}

function logIn() {
    authorizationData.login = document.getElementById("login").value;
    authorizationData.password = document.getElementById("password").value;
    if (authorizationData.checkData(serverAddress)) {
        const content = '<p>Authorized</p>';
        profileBody.innerHTML = content;
        localStorage.setItem('authorized', '1');
        authorizedView();
    }
}

function exit() {
    localStorage.setItem('authorized', '0');
    unauthorizedView();
}

function unauthorizedView() {
    profileBody.innerHTML = '';
    const content = '<form id="form">' + 
    '<label for="login">Введите ваш логин: </label>' +
    '<input id="login" type="text" value=""></input><br>' +
    '<label for="password">Введите ваш пароль: </label>' +
    '<input id="password" type="text" value=""></input><br>' +
    '<input id="submitButton" type="submit" onclick="logIn()"></input>' +
    '</form>';
    profileBody.innerHTML = content;
}

function authorizedView() {
    profileBody.innerHTML = '';
    const content = '<button id="exitButton" type="button" onclick="exit()">Выйти</button>' +
    '<br><p id="responseMsg">' + responseMsg + '</p>';
    profileBody.innerHTML = content;
}

//если пользователь авторизован, вызвать authorizedView(),
//если нет, то вызвать unauthorizedView()
if (localStorage.getItem('authorized') != '0') {
    authorizedView();
} else {
    unauthorizedView();
}